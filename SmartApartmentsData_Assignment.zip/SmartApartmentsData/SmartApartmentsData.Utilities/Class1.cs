﻿using System;

namespace SmartApartmentsData.Utilities
{
    public class Class1
    {
    }
}
