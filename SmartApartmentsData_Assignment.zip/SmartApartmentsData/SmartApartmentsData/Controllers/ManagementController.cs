﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using Nest;
using System.Threading.Tasks;
using SmartApartmentsData.Data.Interfaces;
using SmartApartmentsData.Data;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SmartApartmentsData.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ManagementController : ControllerBase
    {

        private readonly string IndexName = "smart-managements";
        private ISearchManagementInterface searchClient;
        private IUploadJsonInterface indexClient;


        public ManagementController(ISearchManagementInterface searchClient, IUploadJsonInterface indexClient)
        {
            this.searchClient = searchClient;
            this.indexClient = indexClient;
        }


        // GET: api/<ManagementController>
        [HttpGet("{searchQuery}")]
        public async Task<IActionResult> Get(string searchQuery, string market = "", int Limit = 25)
        {
            try
            {
                var searchResponse = await searchClient.SearchIndex(searchQuery, market, Limit);
                if (searchResponse == null) throw new Exception("Check Error Log File");

                return Ok(searchResponse);
            }
            catch (Exception e)
            {
                return BadRequest("Exception occured: " + e.Message);
            }
            
        }


        // POST api/<ManagementController>
        [HttpPost]
        [Route("uploadjson")]
        public async Task<String> UploadJsonDocument(string FileName)
        {
            var result = await indexClient.UploadJsonToIndex(IndexName, FileName);

            return result;
        }

        // POST api/<ManagementController>
        [HttpPost]
        [Route("createindex")]
        public async Task<String> CreateNewIndex(string indexName)
        {
            var result = await indexClient.CreateIndex(indexName);

            return result;
        }

    }
}
