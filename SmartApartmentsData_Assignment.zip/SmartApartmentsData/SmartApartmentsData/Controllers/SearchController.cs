﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SmartApartmentsData.Utilities;
using SmartApartmentsData.Data.Implementation;
using Newtonsoft.Json;
using SmartApartmentsData.Data;
using SmartApartmentsData.Data.Interfaces;


namespace SmartApartmentsData.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SearchController : ControllerBase
    {
        private readonly ISearchPropertyInterface propertiesSearchClient;
        private readonly ISearchManagementInterface managementSearchClient;


        public SearchController(ISearchPropertyInterface propertiesSearchClient, ISearchManagementInterface managementSearchClient)
        {
            this.propertiesSearchClient = propertiesSearchClient;
            this.managementSearchClient = managementSearchClient;


        }

        [HttpGet("Properties/{searchQuery}")]
        public async Task<IActionResult> GetProperties(string searchQuery, string market = "", int Limit = 25) 
        {
            IEnumerable<Properties> result;
            try
            {
               result = await propertiesSearchClient.SearchIndex(searchQuery, market, Limit);
                if (result == null) throw new Exception("Check Error Log File");

            }
            catch (Exception e)
            {
                return BadRequest("Exception occured: " +e.Message);
            }

            return Ok(result);
        }

        [HttpGet]
        [Route("Management/{searchMgmtQuery}")]
        public async Task<IActionResult> GetManagements(string searchMgmtQuery, string market = "", int Limit = 25)
        {
            IEnumerable<Management> result;
            try
            {
                result = await managementSearchClient.SearchIndex(searchMgmtQuery, market, Limit);
                if (result == null) throw new Exception("Check Error Log File");

            }
            catch (Exception e)
            {
                return BadRequest("Exception occured: " + e.Message);
            }

            return Ok(result);

        }

    }
}
