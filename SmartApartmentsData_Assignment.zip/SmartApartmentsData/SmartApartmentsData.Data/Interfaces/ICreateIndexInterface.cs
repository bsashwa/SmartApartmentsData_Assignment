﻿using System.Collections.Generic;
using System.Threading.Tasks;
using SmartApartmentsData.Data;

namespace SmartApartmentsData.Data.Interfaces
{
    public interface ICreateIndexInterface
    {
        public Task<string> CreateIndex(string IndexName);
    }
}
