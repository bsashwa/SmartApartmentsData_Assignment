﻿using System.Collections.Generic;
using System.Threading.Tasks;
using SmartApartmentsData.Data;

namespace SmartApartmentsData.Data.Interfaces
{
    public interface IUploadJsonInterface : ICreateIndexInterface
    {
        public Task<string> UploadJsonToIndex(string IndexName, string FileName);
    }
}