﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartApartmentsData.Utilities
{
    public class Helper
    {
        public static void ErrorLog(string sErrMsg)
        {
            string sLogFormat = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToLongTimeString() + " ==> ";

            //this variable used to create log filename format "
            //for example filename : ErrorLogYYYYMMDD
            var sYear = DateTime.Now.Year.ToString(CultureInfo.InvariantCulture);
            var sMonth = DateTime.Now.Month.ToString(CultureInfo.InvariantCulture);
            var sDay = DateTime.Now.Day.ToString(CultureInfo.InvariantCulture);
            var sErrorTime = sYear + sMonth + sDay;
            if (!Directory.Exists("/Logs/SmartAptData"))
            {
                Directory.CreateDirectory("/Logs/SmartAptData");
            }
            var sw = new StreamWriter("/Logs/SmartAptData/ErrorLog" + sErrorTime + ".txt", true);
            sw.WriteLine(sLogFormat + sErrMsg);
            sw.Flush();
            sw.Close();
        }

    }
}
