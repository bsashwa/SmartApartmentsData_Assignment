﻿namespace SmartApartmentsData.Data
{
    public class Management
    {
        public int MgmtID { get; set; }
        public string Name { get; set; }
        public string Market { get; set; }
        public string State { get; set; }
    }
}
