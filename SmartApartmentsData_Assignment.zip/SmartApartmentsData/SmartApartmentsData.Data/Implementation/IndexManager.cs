﻿using Nest;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartApartmentsData.Data.Interfaces;
using SmartApartmentsData.Utilities;


namespace SmartApartmentsData.Data.Implementation
{
    public class IndexManager : IUploadJsonInterface
    {
        private readonly IElasticClient elasticClient;
        public IndexManager(IElasticClient elasticClient)
        {
            this.elasticClient = elasticClient;
        }
        public async Task<string> CreateIndex(string IndexName)
        {
            var checkIndex = await elasticClient.Indices.ExistsAsync(IndexName);
            if (!checkIndex.Exists)
            {
                var uploadResponse = await elasticClient.Indices.CreateAsync(IndexName, c => c
                .Settings(s => s.Analysis(a => a
                                .TokenFilters(tf => tf
                                    .Stemmer("stemmers", stf => stf
                                        .Language("english"))
                                    .Stop("stop_words_english", sf => sf
                                        .StopWords("_English_")
                                    ))
                   .Tokenizers(tz => tz.
                      NGram("ngram_filter", desc => desc
                          .MinGram(3).MaxGram(4)
                          .TokenChars(new[] { TokenChar.Letter, TokenChar.Digit })
                      )
                   )
                   .Analyzers(ca => ca
                      .Custom("ngram_analyzer", csa => csa
                         .Filters("stop_words_english", "trim", "lowercase", "stemmers")
                         .Tokenizer("ngram_filter"))
                   ))

                ));

                if (!uploadResponse.IsValid) throw new Exception("Error in creating the index: " + IndexName);

            }
            else 
            {
                throw new Exception("Index already exists");
            }
            return "success";
        }

        public async Task<string> UploadJsonToIndex(string IndexName, string filePath)
        {
            try
            {
                if (!File.Exists(filePath)) throw new Exception("File does not Exists");
                if (Path.GetExtension(filePath) == String.Empty) throw new Exception("Invalid File Format");

                StreamReader sq = new StreamReader(filePath);
                var json = await sq.ReadToEndAsync();
                var m = JsonConvert.DeserializeObject<IEnumerable<Management>>(json);

                var indexManyAsyncResponse = await elasticClient.IndexManyAsync(m, IndexName);
                return Convert.ToString(indexManyAsyncResponse.IsValid);
            }
            catch (Exception e) 
            {
                Helper.ErrorLog("Exception in while Uploading Json; " + e.Message);
                return e.Message;
            }
            
        }
    }
}
