﻿using System;
using System.Collections.Generic;
using System.Linq;
using Nest;
using System.Threading.Tasks;
using SmartApartmentsData.Utilities;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using Newtonsoft.Json;
using SmartApartmentsData.Data.Interfaces;


namespace SmartApartmentsData.Data.Implementation
{
    public class PropertiesES : ISearchPropertyInterface
    {
        private readonly IElasticClient elasticClient;
        private readonly string IndexName = "smart-properties";

        public PropertiesES(IElasticClient elasticClient)
        {
            this.elasticClient = elasticClient;
        }


        public async Task<IEnumerable<Properties>> SearchIndex(string searchQuery, string market = "", int searchLimit = 25)
        {
            try
            {
                var response = await elasticClient.SearchAsync<Properties>(s => s
                            .Size(searchLimit)
                            .Index(IndexName)
                            .Query(q =>
                                q.MultiMatch(m => m
                                    .Fields(f => f
                                        .Field(fo => fo.Name)
                                        .Field(ft => ft.StreetAddress)
                                    )
                                    .Analyzer("ngram_analyzer")
                                    .Query(searchQuery)
                                    .Fuzziness(Fuzziness.Auto)
                                    .Operator(Operator.Or)) &&
                                q.Match(m => m
                                    .Field(f => f.Market)
                                    .Query(market))
                            ));
                return response?.Documents;
            }
            catch (Exception e)
            {
                Helper.ErrorLog("Exception while searching for Properties data; " + e.Message);
                return null;
            }

        }

    }
}
