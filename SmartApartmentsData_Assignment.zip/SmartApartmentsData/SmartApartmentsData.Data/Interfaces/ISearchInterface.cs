﻿using System.Collections.Generic;
using System.Threading.Tasks;
using SmartApartmentsData.Data;

namespace SmartApartmentsData.Data.Interfaces
{
    public interface ISearchPropertyInterface 
    {
        public Task<IEnumerable<Properties>> SearchIndex(string searchQuery, string market, int searchLimit);
    }
    public interface ISearchManagementInterface
    {
        public Task<IEnumerable<Management>> SearchIndex(string searchQuery, string market, int searchLimit);
    }
}
